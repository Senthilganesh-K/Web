function searchBooks() {
  const query = document.getElementById("searchBox").value.toLowerCase().trim();
  const books = document.querySelectorAll(".book-card");
  const divider = document.getElementById("divider");
  const countEl = document.getElementById("bookCount");
  
  let visibleCount = 0;
  
  books.forEach((book) => {
    const title = book.getAttribute("data-title").toLowerCase();
    if (title.includes(query)) {
      book.style.display = "flex";
      visibleCount++;
    } else {
      book.style.display = "none";
    }
  });
  
  divider.style.display = visibleCount > 0 ? "block" : "none";
  countEl.textContent = `Books: ${visibleCount}`;
}

function zoomBook(element) {
  document.querySelectorAll(".book-card").forEach((card) => {
    card.classList.remove("zoomed");
  });
  
  element.classList.add("zoomed");
  
  setTimeout(() => {
    element.classList.remove("zoomed");
  }, 1000);
}

// On page load, show total books
window.onload = function() {
  const total = document.querySelectorAll(".book-card").length;
  document.getElementById("ContentCount").textContent = `Contant: ${total}`;
};