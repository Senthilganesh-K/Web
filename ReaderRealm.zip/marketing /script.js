function order(product) {
  alert("You clicked to order: " + product + "\nRedirecting to affiliate link...");
  // You can replace the below line with actual redirect:
  // window.location.href = "https://your-affiliate-link.com";
}